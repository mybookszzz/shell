#!/bin/bash

#author:zhang
#date:2017-03-08

#upgrade python to 2.7.*

#检查现有系统python版本
Py_Version=$(python --version)
echo "当前系统python版本:$Py_Version"
