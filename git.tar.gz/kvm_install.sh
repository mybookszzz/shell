#!/bin/bash
#
#author:zhang
#date:2017-03-17
#

#查看是否支持虚拟化

