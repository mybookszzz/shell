#!/usr/bin/bash 

##Filename:zabbix_server_install.sh
##author:nongmei
##date:2016/03/02


